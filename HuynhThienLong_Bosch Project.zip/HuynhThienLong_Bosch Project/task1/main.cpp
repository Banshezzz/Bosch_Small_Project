#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>

#include "source/text.h"
#include "source/image.h"
#include "source/filereader.h"

#include "model/model.h"

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    //File's name
    const QString Filename = ":/data.json";
    //read data from JSON file
    fileReader *filereader = new fileReader;
    filereader->readFile(Filename);

    //create objects
    /*---model object---*/
    model *model = new class model;
    model->getDataFromFile(*filereader);
    /*---text object---*/
    Text text;
    qmlRegisterType<Image> ("SI", 1, 0, "ImageClass");
    qmlRegisterSingletonType(QUrl("qrc:/HeaderLine.qml"), "MyStyle", 1, 0, "HeaderLine" );

    QQmlApplicationEngine engine;
    QQmlContext *root = engine.rootContext();
    root->setContextProperty("_model", model);
    root->setContextProperty("_text", &text);

    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
