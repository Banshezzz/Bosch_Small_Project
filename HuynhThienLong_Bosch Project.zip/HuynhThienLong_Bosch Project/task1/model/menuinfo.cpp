#include "menuinfo.h"

MenuInfo::MenuInfo()
{

}

const QString &MenuInfo::getTextS() const
{
    return textS;
}

void MenuInfo::setTextS(const QString &newTextS)
{
    textS = newTextS;
}

const QString &MenuInfo::getMenu() const
{
    return menu;
}

void MenuInfo::setMenu(const QString &newMenu)
{
    menu = newMenu;
}

const QString &MenuInfo::getTextL() const
{
    return textL;
}

void MenuInfo::setTextL(const QString &newTextL)
{
    textL = newTextL;
}

const QString &MenuInfo::getImage() const
{
    return image;
}

void MenuInfo::setImage(const QString &newImage)
{
    image = newImage;
}
