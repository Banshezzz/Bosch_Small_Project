#ifndef MENUINFO_H
#define MENUINFO_H

#include <QString>

class MenuInfo
{
public:
    MenuInfo();
    MenuInfo(const QString menu, const QString textL, const QString textS, const QString image)
        : menu(menu), textL(textL), textS(textS), image(image) {}

    const QString &getImage() const;
    void setImage(const QString &newImage);
    const QString &getTextL() const;
    void setTextL(const QString &newTextL);
    const QString &getTextS() const;
    void setTextS(const QString &newTextS);
    const QString &getMenu() const;
    void setMenu(const QString &newMenu);

private:
    QString menu, textL, textS, image;
};

#endif // MENUINFO_H
