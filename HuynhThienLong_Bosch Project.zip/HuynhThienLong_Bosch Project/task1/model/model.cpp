#include "model.h"
#include <QByteArray>

model::model(QObject *parent)
    : QAbstractListModel{parent}
{
}

int model::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
    return m_data.length();
}

void model::getDataFromFile(const fileReader &newfileReader)
{
    fileReader insertedData = newfileReader;
    beginResetModel();
    m_data = insertedData.menuInfo();
    endResetModel();
}

QVariant model::data(const QModelIndex &index, int role) const
{
    if( !index.isValid() )
        return QVariant();

    const MenuInfo &menuInfo = m_data.at(index.row());
    if(role == MenuRole)
        return menuInfo.getMenu();
    else if(role == TextLRole)
        return menuInfo.getTextL();
    else if(role == TextSRole)
        return menuInfo.getTextS();
    else if(role == ImageRole)
        return menuInfo.getImage();
    else
        return QVariant();
}

QHash<int, QByteArray> model::roleNames() const
{
    static QHash<int, QByteArray> mapping {
        {MenuRole, "Menu"},
        {TextLRole, "TextL"},
        {TextSRole, "TextS"},
        {ImageRole, "Image"},
    };
    return mapping;
}
