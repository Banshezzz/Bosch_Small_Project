#ifndef MODEL_H
#define MODEL_H

#include <QObject>
#include <QAbstractListModel>

#include "menuinfo.h"
#include "source/filereader.h"

class model : public QAbstractListModel
{
    Q_OBJECT
public:
    explicit model(QObject *parent = nullptr);
    enum Roles {
        MenuRole,
        TextLRole = Qt::UserRole + 1,
        TextSRole,
        ImageRole
    };

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;
    void getDataFromFile(const fileReader &newfileReader);
    QVariant data( const QModelIndex& index, int role = Qt::DisplayRole ) const override;
    QHash<int, QByteArray> roleNames() const override;

private:
    QVector<MenuInfo> m_data;
};

#endif // MODEL_H
