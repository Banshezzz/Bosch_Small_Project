#include "source/filereader.h"

fileReader::fileReader()
{

}

const QVector<MenuInfo> fileReader::menuInfo()
{
    return m_menuInfo;
}

void fileReader::readFile(const QString &nameFile)
{
    QFile File;
    QByteArray bytedata;

    File.setFileName(nameFile);
    if (!File.open(QIODevice::ReadOnly | QIODevice::Text)){
        qDebug() << "Error occur while open file";
        return;
    }
    qDebug() << "Open file success";
    bytedata = File.readAll();
    convertFromJson(bytedata);
}

void fileReader::convertFromJson(const QByteArray &filedata)
{
    QJsonDocument jsonDoc = QJsonDocument::fromJson(filedata);
    QJsonArray jsonArray = jsonDoc.array();

    for(int i = 0; i < jsonArray.size(); i++){
        // each ele in array is an object
        QJsonObject menus = jsonArray[i].toObject();

        //get values
        QString menu = menus["menu"].toString();
        QString textL = menus["largeText"].toString();
        QString textS = menus["smallText"].toString();
        QString image = menus["image"].toString();

        m_menuInfo.append(MenuInfo(menu, textL, textS, image));
    }
}
