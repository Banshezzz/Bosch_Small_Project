#ifndef FILEREADER_H
#define FILEREADER_H

#include "model/menuinfo.h"

#include <QVector>
#include <QByteArray>
#include <QDebug>

#include <QFile>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>

class fileReader
{
public:
    fileReader();
    const QVector<MenuInfo> menuInfo() ;

    void readFile(const QString &nameFile);
    void convertFromJson(const QByteArray &filedata);

private:
    QVector<MenuInfo> m_menuInfo;
};

#endif // FILEREADER_H
