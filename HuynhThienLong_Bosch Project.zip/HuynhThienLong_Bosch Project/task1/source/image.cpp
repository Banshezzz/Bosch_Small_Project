#include "image.h"

#include <QDebug>

Image::Image(QObject *parent)
    : QObject{parent}
{
    m_Url_back = "qrc:/image/back.png";
    m_Url_detail = "qrc:/image/pic2.jpg";
    m_Url_noWifi = "qrc:/image/no_wifi.png";
    m_Url_clock = "qrc:/image/clock.png";
    m_Url_more = "qrc:/image/more.png";
}

QString Image::Url_back()
{
    return m_Url_back;
}

QString Image::Url_detail()
{
    return m_Url_detail;
}

// Return funcs
QString Image::Url_noWifi()
{
    return m_Url_noWifi;
}

QString Image::Url_clock()
{
    return m_Url_clock;
}

QString Image::Url_more()
{
    return m_Url_more;
}

void Image::setUrl_back(const QString Url)
{
    if(Url == m_Url_back)
        return;

    m_Url_back = Url;
    emit Url_backChanged();
}

void Image::setUrl_detail(const QString Url)
{
    if(Url == m_Url_detail)
        return;

    m_Url_detail = Url;
    emit Url_detailChanged();
}

//Slots
void Image::setUrl_noWifi(const QString Url)
{
    if(Url == m_Url_noWifi)
        return;

    m_Url_noWifi = Url;
    emit Url_noWifiChanged();
}

void Image::setUrl_clock(const QString Url)
{
    if(Url == m_Url_clock)
        return;

    m_Url_clock = Url;
    emit Url_clockChanged();
}

void Image::setUrl_more(const QString Url)
{
    if(Url == m_Url_more)
        return;

    m_Url_more = Url;
    emit Url_moreChanged();
}
