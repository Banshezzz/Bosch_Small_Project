#ifndef IMAGE_H
#define IMAGE_H

#include <QObject>

class Image : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString Url_back READ Url_back WRITE setUrl_back NOTIFY Url_backChanged)
    Q_PROPERTY(QString Url_detail READ Url_detail WRITE setUrl_detail NOTIFY Url_detailChanged)
    Q_PROPERTY(QString Url_noWifi READ Url_noWifi WRITE setUrl_noWifi NOTIFY Url_noWifiChanged)
    Q_PROPERTY(QString Url_clock READ Url_clock WRITE setUrl_clock NOTIFY Url_clockChanged)
    Q_PROPERTY(QString Url_more READ Url_more WRITE setUrl_more NOTIFY Url_moreChanged)

public:
    explicit Image(QObject *parent = nullptr);
    QString Url_back();
    QString Url_detail();
    QString Url_noWifi();
    QString Url_clock();
    QString Url_more();

public slots:
    void setUrl_back(const QString Url);
    void setUrl_detail(const QString Url);
    void setUrl_noWifi(const QString Url);
    void setUrl_clock(const QString Url);
    void setUrl_more(const QString Url);

signals:
    void Url_backChanged();
    void Url_detailChanged();
    void Url_noWifiChanged();
    void Url_clockChanged();
    void Url_moreChanged();

private:
    QString m_Url_back, m_Url_detail, m_Url_noWifi, m_Url_clock, m_Url_more;
};

#endif // IMAGE_H
