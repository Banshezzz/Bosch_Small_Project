#ifndef TEXT_H
#define TEXT_H

#include <QObject>

class Text : public QObject
{
    Q_OBJECT
public:
    explicit Text(QObject *parent = nullptr);
    Q_INVOKABLE QString menuTitle();
private:
    QString m_menuTitle;
};

#endif // TEXT_H
