#include "text.h"
#include <QDebug>

Text::Text(QObject *parent)
    : QObject{parent}
{
    m_menuTitle = "Main menu";
}

QString Text::menuTitle()
{
    return m_menuTitle;
}


